'''
Generate an appropriate data tag to add constant sites to your BEAST2 XML
'''

__version__ = "0.1"
